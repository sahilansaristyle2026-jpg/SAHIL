
import React, { useState } from 'react';
import { Mood, Genre, Tempo, VocalType, SongMetadata } from '../types';
import { generateLyrics } from '../services/geminiService';

interface CreateSongProps {
  onGenerate: (song: SongMetadata) => void;
}

const CreateSong: React.FC<CreateSongProps> = ({ onGenerate }) => {
  const [lyrics, setLyrics] = useState('');
  const [topic, setTopic] = useState('');
  const [mood, setMood] = useState(Mood.CHILL);
  const [genre, setGenre] = useState(Genre.POP);
  const [tempo, setTempo] = useState(Tempo.MID);
  const [vocalType, setVocalType] = useState(VocalType.NEUTRAL);
  const [isGenerating, setIsGenerating] = useState(false);
  const [status, setStatus] = useState('');

  const handleGenerate = async () => {
    setIsGenerating(true);
    setStatus('Analyzing prompt...');
    
    try {
      let finalLyrics = lyrics;
      if (!lyrics && topic) {
        setStatus('Generating original lyrics with Gemini AI...');
        finalLyrics = await generateLyrics(topic, genre, mood);
      } else if (!lyrics && !topic) {
        setStatus('Generating creative inspiration...');
        finalLyrics = await generateLyrics("A futuristic song about the digital soul", genre, mood);
      }

      setStatus('Synthesizing instrumental stems...');
      await new Promise(r => setTimeout(r, 2000));
      
      setStatus('Applying vocal models and mastering...');
      await new Promise(r => setTimeout(r, 2000));

      const newSong: SongMetadata = {
        id: Math.random().toString(36).substr(2, 9),
        title: topic || "AI Composition #" + Math.floor(Math.random() * 1000),
        lyrics: finalLyrics,
        mood,
        genre,
        tempo,
        vocalType,
        duration: 180,
        createdAt: Date.now(),
      };

      onGenerate(newSong);
    } catch (error) {
      console.error(error);
      setStatus('Generation failed.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500 pb-32">
      <div className="space-y-2">
        <h2 className="text-4xl font-outfit font-bold">Create Original Song</h2>
        <p className="text-slate-400">Define your vibe and let Melodia handle the orchestration.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column: Creative Input */}
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-300">What's the song about? (Topic or Prompt)</label>
            <textarea 
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., A rainy night in Neo-Tokyo, feeling nostalgic but hopeful..."
              className="w-full h-32 bg-slate-900 border border-slate-800 rounded-xl p-4 text-slate-100 placeholder:text-slate-600 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <label className="text-sm font-semibold text-slate-300">Own Lyrics (Optional)</label>
              <button onClick={() => setLyrics('')} className="text-xs text-indigo-400 hover:underline">Clear</button>
            </div>
            <textarea 
              value={lyrics}
              onChange={(e) => setLyrics(e.target.value)}
              placeholder="Paste your lyrics here if you have them..."
              className="w-full h-48 bg-slate-900 border border-slate-800 rounded-xl p-4 text-slate-100 placeholder:text-slate-600 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>
        </div>

        {/* Right Column: Style Options */}
        <div className="space-y-8 glass p-8 rounded-2xl border border-slate-800/50">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-300">Genre</label>
              <select 
                value={genre} 
                onChange={(e) => setGenre(e.target.value as Genre)}
                className="w-full bg-slate-800 border-none rounded-lg p-2 text-slate-200 outline-none"
              >
                {Object.values(Genre).map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-300">Mood</label>
              <select 
                value={mood} 
                onChange={(e) => setMood(e.target.value as Mood)}
                className="w-full bg-slate-800 border-none rounded-lg p-2 text-slate-200 outline-none"
              >
                {Object.values(Mood).map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-300">Tempo</label>
              <select 
                value={tempo} 
                onChange={(e) => setTempo(e.target.value as Tempo)}
                className="w-full bg-slate-800 border-none rounded-lg p-2 text-slate-200 outline-none"
              >
                {Object.values(Tempo).map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-300">Vocal Style</label>
              <select 
                value={vocalType} 
                onChange={(e) => setVocalType(e.target.value as VocalType)}
                className="w-full bg-slate-800 border-none rounded-lg p-2 text-slate-200 outline-none"
              >
                {Object.values(VocalType).map(v => <option key={v} value={v}>{v}</option>)}
              </select>
            </div>
          </div>

          <div className="pt-4">
            <button 
              onClick={handleGenerate}
              disabled={isGenerating}
              className={`w-full py-4 rounded-xl font-bold text-lg shadow-xl shadow-indigo-500/20 transition-all flex items-center justify-center gap-3
                ${isGenerating 
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white active:scale-95'
                }`}
            >
              {isGenerating ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span>Generating...</span>
                </>
              ) : 'Compose Song'}
            </button>
            {isGenerating && (
              <p className="mt-4 text-center text-sm text-indigo-400 font-mono animate-pulse">
                {status}
              </p>
            )}
          </div>

          <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-800 text-xs text-slate-500 leading-relaxed">
            <p>• Copyright-safe generation (Original AI models)</p>
            <p>• No artist names allowed in prompts</p>
            <p>• Output is owned by the user (Melodia Standard License)</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateSong;
