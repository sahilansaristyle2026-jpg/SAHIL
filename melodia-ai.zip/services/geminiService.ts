
import { GoogleGenAI, Type } from "@google/genai";
import { Genre, Mood, ImageAnalysis } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateLyrics = async (topic: string, genre: Genre, mood: Mood): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate emotional, high-quality lyrics for a ${genre} song with a ${mood} mood. The topic is: ${topic}. Structure it with Verse 1, Chorus, Verse 2, Chorus, Bridge, and Outro.`,
      config: {
        temperature: 0.8,
        topP: 0.95,
      },
    });
    return response.text || "Lyrics generation failed. Please try again.";
  } catch (error) {
    console.error("Gemini Lyrics Error:", error);
    return "Error connecting to lyric engine.";
  }
};

export const analyzeImageForMusic = async (base64Image: string): Promise<ImageAnalysis> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        {
          text: `Analyze this image for musical inspiration. Return a JSON object with: 
                 - colors (array of primary strings)
                 - emotion (one word)
                 - scene (brief description)
                 - vibe (descriptive phrase)
                 - suggestedGenre (one of: Pop, EDM, Hip-Hop, Trap, Rock, Lo-Fi, Jazz)
                 - suggestedMood (one of: Sad, Party, Romantic, Dark, Cinematic, Chill, Upbeat)
                 - autoLyrics (lyrics based on the image context)`
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            colors: { type: Type.ARRAY, items: { type: Type.STRING } },
            emotion: { type: Type.STRING },
            scene: { type: Type.STRING },
            vibe: { type: Type.STRING },
            suggestedGenre: { type: Type.STRING },
            suggestedMood: { type: Type.STRING },
            autoLyrics: { type: Type.STRING },
          },
          required: ["colors", "emotion", "scene", "vibe", "suggestedGenre", "suggestedMood", "autoLyrics"],
        }
      },
    });

    const data = JSON.parse(response.text || "{}");
    return data as ImageAnalysis;
  } catch (error) {
    console.error("Gemini Image Analysis Error:", error);
    throw error;
  }
};
