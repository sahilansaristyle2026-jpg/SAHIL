
import React, { useState } from 'react';
import { ICONS } from '../constants';
import { analyzeImageForMusic } from '../services/geminiService';
import { SongMetadata, Genre, Mood, Tempo, VocalType } from '../types';

interface ImageToMusicProps {
  onGenerate: (song: SongMetadata) => void;
}

const ImageToMusic: React.FC<ImageToMusicProps> = ({ onGenerate }) => {
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const processImage = async () => {
    if (!image) return;
    setIsAnalyzing(true);
    try {
      const base64 = image.split(',')[1];
      const result = await analyzeImageForMusic(base64);
      setAnalysis(result);
      
      // Auto-trigger generation after a short delay to simulate "Music Engine"
      setTimeout(() => {
        const newSong: SongMetadata = {
          id: Math.random().toString(36).substr(2, 9),
          title: `Portrait of ${result.emotion}`,
          lyrics: result.autoLyrics,
          mood: result.suggestedMood as Mood,
          genre: result.suggestedGenre as Genre,
          tempo: Tempo.MID,
          vocalType: VocalType.NEUTRAL,
          duration: 150,
          createdAt: Date.now(),
        };
        onGenerate(newSong);
      }, 3000);

    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-700">
      <div className="space-y-2">
        <h2 className="text-4xl font-outfit font-bold">Photo to Song</h2>
        <p className="text-slate-400">Capture the vibe of an image and transform it into a sonic landscape.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className={`relative aspect-square rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center p-4 
            ${image ? 'border-indigo-500/50 bg-indigo-500/5' : 'border-slate-800 hover:border-slate-700 bg-slate-900/50'}`}>
            {image ? (
              <img src={image} alt="Uploaded" className="w-full h-full object-cover rounded-xl" />
            ) : (
              <div className="text-center space-y-4">
                <ICONS.Image className="w-12 h-12 text-slate-600 mx-auto" />
                <div>
                  <p className="text-slate-300 font-medium">Drop your image here</p>
                  <p className="text-xs text-slate-500 mt-1">PNG, JPG or WEBP (Max 10MB)</p>
                </div>
                <label className="inline-block px-6 py-2 bg-slate-800 text-slate-200 rounded-lg cursor-pointer hover:bg-slate-700 transition-colors">
                  Choose File
                  <input type="file" className="hidden" onChange={handleFileChange} accept="image/*" />
                </label>
              </div>
            )}
            {image && !isAnalyzing && !analysis && (
              <button 
                onClick={() => setImage(null)}
                className="absolute top-4 right-4 bg-slate-950/80 p-2 rounded-full hover:bg-red-500 transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            )}
          </div>

          {image && !analysis && (
            <button 
              onClick={processImage}
              disabled={isAnalyzing}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-indigo-600/20 disabled:opacity-50"
            >
              {isAnalyzing ? 'Analyzing with Gemini...' : 'Analyze & Generate'}
            </button>
          )}
        </div>

        <div className="space-y-6">
          {analysis ? (
            <div className="glass p-8 rounded-2xl border border-slate-800/50 space-y-6 animate-in fade-in zoom-in duration-500">
              <h3 className="text-xl font-bold font-outfit text-indigo-400">Sonic Analysis Result</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-900/50 rounded-lg">
                  <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold mb-1">Mood</p>
                  <p className="text-slate-200">{analysis.suggestedMood}</p>
                </div>
                <div className="p-3 bg-slate-900/50 rounded-lg">
                  <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold mb-1">Genre</p>
                  <p className="text-slate-200">{analysis.suggestedGenre}</p>
                </div>
                <div className="p-3 bg-slate-900/50 rounded-lg">
                  <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold mb-1">Emotion</p>
                  <p className="text-slate-200">{analysis.emotion}</p>
                </div>
                <div className="p-3 bg-slate-900/50 rounded-lg">
                  <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold mb-1">Primary Color</p>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: analysis.colors[0] }}></div>
                    <p className="text-slate-200">{analysis.colors[0]}</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Auto-Generated Lyrics</p>
                <div className="bg-slate-950/50 p-4 rounded-xl text-sm italic text-slate-400 line-clamp-6 leading-relaxed">
                  {analysis.autoLyrics}
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-indigo-900/20 border border-indigo-500/20 rounded-xl">
                <div className="w-2 h-2 bg-indigo-500 rounded-full animate-ping"></div>
                <p className="text-sm text-indigo-300">Rendering high-fidelity track...</p>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 border border-slate-800 rounded-2xl bg-slate-900/20 text-slate-500">
              <ICONS.Music className="w-12 h-12 mb-4 opacity-20" />
              <p>Upload an image to reveal the hidden melodies within its pixels.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageToMusic;
