
import React, { useState, useEffect } from 'react';
import { Page, SongMetadata, Mood, Genre, Tempo, VocalType } from './types';
import Sidebar from './components/Sidebar';
import MusicPlayer from './components/MusicPlayer';
import CreateSong from './components/CreateSong';
import ImageToMusic from './components/ImageToMusic';
import RemixStudio from './components/RemixStudio';
import { ICONS } from './constants';

const App: React.FC = () => {
  const [page, setPage] = useState<Page>('home');
  const [currentTrack, setCurrentTrack] = useState<SongMetadata | null>(null);
  const [library, setLibrary] = useState<SongMetadata[]>([]);

  // Load mock initial data
  useEffect(() => {
    const mockLibrary: SongMetadata[] = [
      {
        id: '1',
        title: 'Neon Horizon',
        genre: Genre.EDM,
        mood: Mood.UPBEAT,
        tempo: Tempo.FAST,
        vocalType: VocalType.FEMALE,
        lyrics: 'Chasing the stars in a digital cage...',
        duration: 210,
        createdAt: Date.now() - 86400000,
      },
      {
        id: '2',
        title: 'Midnight Echoes',
        genre: Genre.LOFI,
        mood: Mood.CHILL,
        tempo: Tempo.SLOW,
        vocalType: VocalType.NEUTRAL,
        lyrics: 'Soft rain against the glass, memories fading fast...',
        duration: 185,
        createdAt: Date.now() - 172800000,
      }
    ];
    setLibrary(mockLibrary);
  }, []);

  const handleGenerate = (newSong: SongMetadata) => {
    setLibrary([newSong, ...library]);
    setCurrentTrack(newSong);
    setPage('library');
  };

  const renderPage = () => {
    switch (page) {
      case 'home':
        return (
          <div className="space-y-16 animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <header className="space-y-6 pt-12">
              <h2 className="text-7xl font-outfit font-extrabold tracking-tight">
                Create music at the <br />
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 via-violet-400 to-indigo-500">
                  speed of imagination.
                </span>
              </h2>
              <p className="text-xl text-slate-400 max-w-2xl leading-relaxed">
                The first professional AI music platform that understands vision, 
                lyrics, and sound to build completely original tracks.
              </p>
              <div className="flex gap-4 pt-4">
                <button 
                  onClick={() => setPage('create')}
                  className="px-8 py-4 bg-white text-slate-950 rounded-full font-bold text-lg hover:scale-105 transition-all shadow-2xl shadow-white/10"
                >
                  Start Composing
                </button>
                <button 
                  onClick={() => setPage('remix')}
                  className="px-8 py-4 bg-slate-900 text-slate-100 border border-slate-700 rounded-full font-bold text-lg hover:bg-slate-800 transition-all"
                >
                  Explore Studio
                </button>
              </div>
            </header>

            <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="glass p-8 rounded-3xl border border-slate-800/50 space-y-4 group hover:border-indigo-500/30 transition-colors">
                <div className="w-12 h-12 bg-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white transition-all">
                  <ICONS.Create className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-outfit">Lyric Master</h3>
                <p className="text-slate-400 text-sm leading-relaxed">Input your lyrics or a simple prompt. Melodia crafts professional-grade arrangements instantly.</p>
              </div>
              <div className="glass p-8 rounded-3xl border border-slate-800/50 space-y-4 group hover:border-violet-500/30 transition-colors">
                <div className="w-12 h-12 bg-violet-500/20 rounded-2xl flex items-center justify-center text-violet-400 group-hover:bg-violet-500 group-hover:text-white transition-all">
                  <ICONS.Image className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-outfit">Visual Sonics</h3>
                <p className="text-slate-400 text-sm leading-relaxed">Upload any image. Our AI analyzes color, scene, and mood to generate a matching soundscape.</p>
              </div>
              <div className="glass p-8 rounded-3xl border border-slate-800/50 space-y-4 group hover:border-blue-500/30 transition-colors">
                <div className="w-12 h-12 bg-blue-500/20 rounded-2xl flex items-center justify-center text-blue-400 group-hover:bg-blue-500 group-hover:text-white transition-all">
                  <ICONS.Music className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-outfit">Stem Separation</h3>
                <p className="text-slate-400 text-sm leading-relaxed">Upload existing tracks to remix, extend, or swap instruments with surgical AI precision.</p>
              </div>
            </section>
          </div>
        );
      case 'create':
        return <CreateSong onGenerate={handleGenerate} />;
      case 'image-to-music':
        return <ImageToMusic onGenerate={handleGenerate} />;
      case 'remix':
        return <RemixStudio />;
      case 'library':
        return (
          <div className="space-y-8 animate-in fade-in duration-500 pb-32">
            <div className="flex justify-between items-end">
              <div className="space-y-2">
                <h2 className="text-4xl font-outfit font-bold">My Library</h2>
                <p className="text-slate-400">All your AI-generated and remixed masterpieces.</p>
              </div>
              <button onClick={() => setPage('create')} className="px-6 py-2 bg-indigo-600 rounded-lg font-bold text-sm">New Creation</button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {library.map((song) => (
                <div 
                  key={song.id}
                  className={`glass group p-6 rounded-2xl border transition-all cursor-pointer relative overflow-hidden
                    ${currentTrack?.id === song.id ? 'border-indigo-500 bg-indigo-500/5' : 'border-slate-800 hover:border-slate-700'}`}
                  onClick={() => setCurrentTrack(song)}
                >
                  <div className="aspect-square rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 mb-4 flex items-center justify-center relative overflow-hidden">
                    <ICONS.Music className="w-12 h-12 text-slate-700" />
                    <div className="absolute inset-0 bg-indigo-600/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-xl">
                        <ICONS.Play className="w-6 h-6 text-indigo-600 translate-x-0.5" />
                      </div>
                    </div>
                  </div>
                  <h4 className="font-bold text-slate-100 mb-1 truncate">{song.title}</h4>
                  <p className="text-xs text-slate-500 uppercase tracking-widest font-bold mb-3">{song.genre} • {song.mood}</p>
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                    <span>{Math.floor(song.duration / 60)}:{(song.duration % 60).toString().padStart(2, '0')}</span>
                    <span>{new Date(song.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'upload':
        return (
          <div className="h-[60vh] flex flex-col items-center justify-center text-center space-y-6">
            <div className="w-20 h-20 bg-slate-900 rounded-3xl border border-slate-800 flex items-center justify-center mb-4">
              <ICONS.Upload className="w-10 h-10 text-indigo-500" />
            </div>
            <h2 className="text-3xl font-bold font-outfit">Upload for Stem Separation</h2>
            <p className="text-slate-400 max-w-md">Drop any MP3/WAV to isolate vocals, drums, or bass for remixing.</p>
            <label className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold cursor-pointer hover:bg-indigo-500 transition-all">
              Choose Track
              <input type="file" className="hidden" accept="audio/*" onChange={() => setPage('remix')} />
            </label>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Sidebar currentPage={page} setPage={setPage} />
      
      <main className="pl-64 pr-8 pt-8 min-h-screen">
        <div className="max-w-[1400px] mx-auto pb-32">
          {renderPage()}
        </div>
      </main>

      <MusicPlayer currentTrack={currentTrack} />

      {/* Copyright Warning & Legal Modal Overlay (Subtle) */}
      <div className="fixed top-4 right-8 z-[60] bg-slate-950/80 backdrop-blur border border-slate-800 py-2 px-4 rounded-full flex items-center gap-3 text-xs text-slate-500">
        <div className="w-2 h-2 rounded-full bg-green-500"></div>
        <span>Copyright-Safe AI Engine Active</span>
        <div className="w-px h-3 bg-slate-800"></div>
        <button className="hover:text-slate-300">Terms of Ownership</button>
      </div>
    </div>
  );
};

export default App;
