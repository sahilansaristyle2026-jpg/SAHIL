
export enum Mood {
  SAD = 'Sad',
  PARTY = 'Party',
  ROMANTIC = 'Romantic',
  DARK = 'Dark',
  CINEMATIC = 'Cinematic',
  CHILL = 'Chill',
  UPBEAT = 'Upbeat'
}

export enum Genre {
  POP = 'Pop',
  EDM = 'EDM',
  HIPHOP = 'Hip-Hop',
  TRAP = 'Trap',
  ROCK = 'Rock',
  LOFI = 'Lo-Fi',
  JAZZ = 'Jazz'
}

export enum Tempo {
  SLOW = 'Slow',
  MID = 'Mid',
  FAST = 'Fast'
}

export enum VocalType {
  MALE = 'Male',
  FEMALE = 'Female',
  NEUTRAL = 'AI Neutral'
}

export interface SongMetadata {
  id: string;
  title: string;
  lyrics: string;
  mood: Mood;
  genre: Genre;
  tempo: Tempo;
  vocalType: VocalType;
  duration: number; // in seconds
  coverUrl?: string;
  audioUrl?: string;
  createdAt: number;
}

export interface ImageAnalysis {
  colors: string[];
  emotion: string;
  scene: string;
  vibe: string;
  suggestedGenre: Genre;
  suggestedMood: Mood;
  autoLyrics: string;
}

export type Page = 'home' | 'create' | 'remix' | 'library' | 'upload' | 'image-to-music';
