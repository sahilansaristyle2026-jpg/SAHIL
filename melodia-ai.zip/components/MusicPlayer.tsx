
import React, { useState, useEffect } from 'react';
import { ICONS } from '../constants';
import { SongMetadata } from '../types';

interface MusicPlayerProps {
  currentTrack: SongMetadata | null;
}

const MusicPlayer: React.FC<MusicPlayerProps> = ({ currentTrack }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let interval: any;
    if (isPlaying && currentTrack) {
      interval = setInterval(() => {
        setProgress((prev) => (prev >= 100 ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentTrack]);

  if (!currentTrack) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 h-24 glass border-t border-slate-800 flex items-center px-8 gap-8 z-[100]">
      {/* Track Info */}
      <div className="flex items-center gap-4 w-1/4 min-w-[200px]">
        <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 shadow-lg flex items-center justify-center">
          <ICONS.Music className="w-6 h-6 text-white" />
        </div>
        <div className="overflow-hidden">
          <h4 className="font-semibold text-slate-100 truncate">{currentTrack.title}</h4>
          <p className="text-sm text-slate-400 truncate">{currentTrack.genre} • {currentTrack.mood}</p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex-1 flex flex-col items-center gap-2 max-w-xl">
        <div className="flex items-center gap-6">
          <button className="text-slate-400 hover:text-slate-100 transition-colors">
            <ICONS.SkipBack className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-10 h-10 flex items-center justify-center bg-slate-100 text-slate-950 rounded-full hover:scale-105 transition-transform"
          >
            {isPlaying ? <ICONS.Pause className="w-5 h-5" /> : <ICONS.Play className="w-5 h-5" />}
          </button>
          <button className="text-slate-400 hover:text-slate-100 transition-colors">
            <ICONS.SkipForward className="w-5 h-5" />
          </button>
        </div>
        
        <div className="w-full flex items-center gap-3">
          <span className="text-[10px] font-mono text-slate-500">0:00</span>
          <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden cursor-pointer relative group">
            <div 
              className="h-full bg-indigo-500 transition-all duration-300" 
              style={{ width: `${progress}%` }}
            ></div>
            <div 
              className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ left: `${progress}%` }}
            ></div>
          </div>
          <span className="text-[10px] font-mono text-slate-500">3:24</span>
        </div>
      </div>

      {/* Volume / Extra */}
      <div className="w-1/4 flex justify-end items-center gap-4">
        <div className="flex items-center gap-2">
          <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
          </svg>
          <div className="w-24 h-1 bg-slate-800 rounded-full overflow-hidden">
            <div className="w-2/3 h-full bg-slate-400"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MusicPlayer;
