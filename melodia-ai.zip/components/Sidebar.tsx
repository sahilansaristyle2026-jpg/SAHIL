
import React from 'react';
import { Page } from '../types';
import { ICONS, APP_NAME } from '../constants';

interface SidebarProps {
  currentPage: Page;
  setPage: (page: Page) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentPage, setPage }) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: ICONS.Home },
    { id: 'create', label: 'Create Song', icon: ICONS.Create },
    { id: 'remix', label: 'Remix Studio', icon: ICONS.Music },
    { id: 'image-to-music', label: 'Photo to Song', icon: ICONS.Image },
    { id: 'upload', label: 'Upload Music', icon: ICONS.Upload },
    { id: 'library', label: 'My Library', icon: ICONS.Library },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 glass border-r border-slate-800 flex flex-col z-50">
      <div className="p-8">
        <h1 className="text-2xl font-outfit font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-violet-500">
          {APP_NAME}
        </h1>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setPage(item.id as Page)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              currentPage === item.id 
              ? 'bg-indigo-600/20 text-indigo-400 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.1)]' 
              : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/50'
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-slate-800">
        <div className="glass rounded-xl p-4 text-xs text-slate-400">
          <p className="font-semibold text-slate-200 mb-1">Free Tier</p>
          <div className="w-full h-1.5 bg-slate-800 rounded-full mb-2">
            <div className="w-2/3 h-full bg-indigo-500 rounded-full"></div>
          </div>
          <p>2 of 3 daily generations used.</p>
          <button className="mt-3 w-full py-2 bg-slate-100 text-slate-950 rounded-lg font-bold hover:bg-white transition-colors">
            Upgrade Pro
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
