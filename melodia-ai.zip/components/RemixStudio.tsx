
import React, { useState } from 'react';
import { ICONS } from '../constants';

const RemixStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'remix' | 'replace' | 'extend'>('remix');
  const [isProcessing, setIsProcessing] = useState(false);

  const mockTimeline = Array.from({ length: 40 }).map((_, i) => (
    <div 
      key={i} 
      className="w-1.5 rounded-full bg-slate-700"
      style={{ height: `${20 + Math.random() * 60}%` }}
    />
  ));

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-500 pb-32">
      <div className="flex justify-between items-end">
        <div className="space-y-2">
          <h2 className="text-4xl font-outfit font-bold">Remix Studio</h2>
          <p className="text-slate-400">Transform existing tracks with surgical precision.</p>
        </div>
        <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-800">
          {(['remix', 'replace', 'extend'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-2 rounded-md text-sm font-semibold capitalize transition-all ${
                activeTab === tab ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Timeline View */}
          <div className="glass p-8 rounded-2xl border border-slate-800/50">
            <div className="flex justify-between mb-6">
              <h3 className="font-bold">Timeline Editor</h3>
              <div className="flex gap-4 text-xs font-mono text-slate-500">
                <span>00:00:00</span>
                <span>/</span>
                <span>00:03:42</span>
              </div>
            </div>

            <div className="h-48 bg-slate-950 rounded-xl border border-slate-800 relative overflow-hidden flex items-center justify-center gap-1 px-4">
              {mockTimeline}
              {/* Playhead */}
              <div className="absolute left-1/3 top-0 bottom-0 w-0.5 bg-indigo-500 z-10 shadow-[0_0_10px_rgba(99,102,241,0.5)]">
                <div className="w-3 h-3 bg-indigo-500 rounded-full -ml-[5px] -mt-1 shadow-lg"></div>
              </div>
              {/* Selection Area */}
              <div className="absolute left-1/4 right-1/2 top-0 bottom-0 bg-indigo-500/10 border-x border-indigo-500/50"></div>
            </div>

            <div className="mt-8 grid grid-cols-4 gap-4">
              <button className="flex flex-col items-center gap-2 p-4 bg-slate-900 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors">
                <ICONS.Play className="w-5 h-5 text-slate-400" />
                <span className="text-[10px] font-bold uppercase tracking-widest">Preview</span>
              </button>
              <button className="flex flex-col items-center gap-2 p-4 bg-slate-900 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors">
                <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                <span className="text-[10px] font-bold uppercase tracking-widest">Isolate</span>
              </button>
              <button className="flex flex-col items-center gap-2 p-4 bg-slate-900 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors">
                <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                <span className="text-[10px] font-bold uppercase tracking-widest">Clear Selection</span>
              </button>
              <button className="flex flex-col items-center gap-2 p-4 bg-indigo-600/20 hover:bg-indigo-600/30 rounded-xl border border-indigo-500/30 transition-colors">
                <svg className="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4-4m0 0L8 8m4-4v12" /></svg>
                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">Export Stems</span>
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="glass p-8 rounded-2xl border border-slate-800/50 space-y-8">
            <h3 className="font-bold text-lg">Control Panel</h3>
            
            {activeTab === 'remix' && (
              <div className="space-y-4">
                <p className="text-sm text-slate-400">Change the genre or style while keeping the melody intact.</p>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Target Genre</label>
                  <select className="w-full bg-slate-900 rounded-lg p-3 text-sm border border-slate-800">
                    <option>Deep House</option>
                    <option>Synthwave</option>
                    <option>Acoustic Folk</option>
                    <option>Orchestral</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Variation Strength</label>
                  <input type="range" className="w-full h-1.5 bg-slate-800 rounded-full appearance-none accent-indigo-500" />
                  <div className="flex justify-between text-[10px] text-slate-600">
                    <span>Subtle</span>
                    <span>Total Reimagining</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'replace' && (
              <div className="space-y-4">
                <p className="text-sm text-slate-400">Select a part in the timeline to swap components.</p>
                <div className="grid grid-cols-2 gap-3">
                  <button className="px-4 py-2 bg-slate-800 rounded-lg text-xs font-bold hover:bg-slate-700">Swap Drums</button>
                  <button className="px-4 py-2 bg-slate-800 rounded-lg text-xs font-bold hover:bg-slate-700">Swap Vocals</button>
                  <button className="px-4 py-2 bg-slate-800 rounded-lg text-xs font-bold hover:bg-slate-700">Swap Bass</button>
                  <button className="px-4 py-2 bg-slate-800 rounded-lg text-xs font-bold hover:bg-slate-700">Swap Melodies</button>
                </div>
              </div>
            )}

            {activeTab === 'extend' && (
              <div className="space-y-4">
                <p className="text-sm text-slate-400">Generatively extend your track based on the current context.</p>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Extension Length</label>
                  <select className="w-full bg-slate-900 rounded-lg p-3 text-sm border border-slate-800">
                    <option>+ 30 seconds</option>
                    <option>+ 60 seconds</option>
                    <option>+ 2 minutes</option>
                  </select>
                </div>
              </div>
            )}

            <button 
              onClick={() => setIsProcessing(true)}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition-all"
            >
              {isProcessing ? 'AI Engine Processing...' : 'Apply AI Transformation'}
            </button>

            {isProcessing && (
              <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-xl space-y-3 animate-pulse">
                <div className="flex justify-between text-xs text-indigo-400">
                  <span>Rendering...</span>
                  <span>42%</span>
                </div>
                <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-[42%] h-full bg-indigo-500"></div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RemixStudio;
